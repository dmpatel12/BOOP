#include<iostream>
using namespace std;
void getdata(int a, flot b);
void putdata();
class item
{ 
private:
	int number;
	float price;
	public:
		number =n;
		price=p
};
void item::getdata(int a,float b) 
{
	num=a;
	cost= b;
}
void item::putdata() 
{
	cout<<"number "<<num<<endl
	    <<"cost"<<cost<<endl;
}
int main()
{
	obj m;
	object.item=putdata();
	object.item=getdata(int a,float b);
	return 0;
}
