#include<iostream>
#include<conio.h>
using namespace std
    struct college_info
{
	char college_name[15];
	int college_code[2];
	char dept[50];
	int intake;
}
    int main()
{
	structure college_info;
	cout<<"\n +++++ enter the college information +++++\n \n;"
	cout<<"name of the college";
	cin>>college.college_name;
	cout<<"college code:";
	cin>>college.college_code;
	cout<<"department:";
	cin>>college.dept;
	cout<<"department in_take:";
	cin>>college.int take;
   	cout<<"\n\n*********college information \n\n";
   	cout<<"name of the college:"<<college.college_name;
   	cout<<"\n college university code:"<<college.college_code;
   	cout<<"\n name the departmenet of:"<<college dept;
   	cout<<"\n the departmenet of"<<college.dept<<"has in_take:"<<college intake;
   	cout<<
}
